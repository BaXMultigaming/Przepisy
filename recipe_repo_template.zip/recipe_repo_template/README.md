# Recipe repository template

This template intentionally uses the official TheMealDB API rather than scraping Allrecipes.

## Run locally

```bash
python scripts/sync_recipes.py
python -m http.server 8000
```

Open `http://localhost:8000`.

## GitHub Pages

Enable Pages for the repository root (`main` branch). `index.html` reads `data/recipes_manifest.json` and then the selected recipe JSON.

## API key

The script defaults to TheMealDB development key `1`. You may add a repository secret named `THEMEALDB_API_KEY` for your own supporter/production key.
